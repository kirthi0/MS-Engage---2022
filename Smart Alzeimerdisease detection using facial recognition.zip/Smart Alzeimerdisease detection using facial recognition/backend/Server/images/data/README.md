## The Data Folder
This folder where the data like image name and person name will be inserted to thier file