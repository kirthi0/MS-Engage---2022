## The Train Images Folder
This folder where the train images will be uploaded