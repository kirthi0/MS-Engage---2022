## The Test Images Folder
This folder where the test images will be uploaded