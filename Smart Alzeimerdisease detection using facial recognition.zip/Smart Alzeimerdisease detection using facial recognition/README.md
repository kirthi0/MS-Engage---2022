
Smart Android Assistant App for Alzheimer's Disease Patients

Workflow:
- Designed the user interface with consideration of Computer-Human Interaction guidelines.
- Built a face recognition system with the face_recognition library which has a 99.38% accuracy.
- Developed the backend REST API using Flask which hosted the face recognition system.
- Deployed the Flask server on Heroku which led to reducing the time of testing.
- Implemented the frontend in Android Studio using Java with the support of Camera & Gallery.

Requirements:
- Android Studio
- Java
- Python3
- Flask

Installation and Running:
- Clone the repo: `git clone git@github.com:kirthi0/MS-Engage - 2022.git`
- Install the requirements
- Open App in Android Studio
- Open Server in VS Code or Pycharm
- Buid and run 
